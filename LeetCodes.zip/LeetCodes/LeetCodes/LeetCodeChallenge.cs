﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;

namespace LeetCodes
{
    [TestClass]
    public class LeetCodeChallenge
    {
        [TestMethod]
        public void TestMethod1()
        {
        }

        [TestMethod]
        public void Test_SingleNumber()
        {
            /*Given a non-empty array of integers, every element appears twice except for one. Find that single one.Note:Your algorithm should have a linear runtime complexity. Could you implement it without using extra memory?
              Example 1:Input: [2,2,1] Output: 1 Example 2: Input: [4,1,2,1,2] Output: 4 */
            Assert.AreEqual(SingleNumber(new int[] { 4, 1, 2, 1, 2 }), 4);
            Assert.AreEqual(SingleNumber2(new int[] { 4, 1, 2, 1, 2 }), 4);
            Assert.AreEqual(SingleNumber3(new int[] { 4, 1, 2, 1, 2 }), 4);
            Assert.AreEqual(SingleNumber4(new int[] { 4, 1, 2, 1, 2 }), 4);

        }
        public int SingleNumber(int[] nums)
        {//[4,1,2,1,2]
            if (nums.Length % 2 == 0) return 0;
            Array.Sort(nums);
            int i = 0;
            while (i < nums.Length - 1)
            {
                if (nums[i] != nums[i + 1]) return nums[i];
                else i = i + 2;
            }
            return nums[i];
        }
        public int SingleNumber2(int[] nums)
        {//[4,1,2,1,2]
            if (nums.Length % 2 == 0) return 0;
            var hashSet = new HashSet<int>();
            for (int i = 0; i < nums.Length; i++)
            {
                if (!hashSet.Contains(nums[i]))
                {
                    hashSet.Add(nums[i]);
                }
                else
                {
                    hashSet.Remove(nums[i]);
                }
            }
            return hashSet.First();
        }
        //the best algo
        public int SingleNumber3(int[] nums)
        {/*
            a) XOR of a number with itself is 0.  (1^1 , 0^0 => 0)   x^x => 0
            b) XOR of a number with 0 is number itself. (1^0, 0^1 => 1)     x^0 => x
            array = {7,3,5,4,5,3,4}
            res = 7 ^ 3 ^ 5 ^ 4 ^ 5 ^ 3 ^ 4
            Since XOR is associative and commutative, above 
            expression can be written as:
            res = 7 ^ (3 ^ 3) ^ (4 ^ 4) ^ (5 ^ 5)  
                = 7 ^ 0 ^ 0 ^ 0
                = 7 ^ 0
                = 7 */
            int res = nums[0];
            for (int i = 1; i < nums.Length; i++)
                res = res ^ nums[i];
            return res;
        }
        public int SingleNumber4(int[] nums)
        {
            int sum_nums = nums.Sum();
            var hash = new HashSet<int>(nums);
            int[] array2 = hash.ToArray();
            return (2 * array2.Sum()) - (sum_nums);
        }

        /*Write an algorithm to determine if a number is "happy".
        A happy number is a number defined by the following process: Starting with any positive integer, replace the number by the sum of the squares of its digits, and repeat the process until the number equals 1 (where it will stay), or it loops endlessly in a cycle which does not include 1. Those numbers for which this process ends in 1 are happy numbers.
         example:
        Input: 19
        Output: true
        Explanation: 
        12 + 92 = 82
        82 + 22 = 68
        62 + 82 = 100
        12 + 02 + 02 = 1
             */
        [TestMethod]
        public void Test_happyNumber()
        {
            //Assert.IsTrue(IsHappy(13));
            //Assert.IsFalse(IsHappy(4));

            Assert.IsTrue(IsHappy2(13));
            Assert.IsFalse(IsHappy2(4));
        }
        public bool IsHappy(int n)
        {
            int y = n;

            while (y > 10)
            {
                y = SumSquare(y);
                if (y == 1) return true;
            }
            if (y == 1 || y == 7 || y == 10) return true;
            return false;
        }
        public int SumSquare(int n)
        {
            int x = n;
            int sum = 0;
            while (x >= 10)
            {
                sum += (int)Math.Pow((x % 10), 2);
                x = x / 10;
            }
            sum += (int)Math.Pow(x, 2);
            return sum;
        }
        //using hashset to trace the number being calculated to avoid endless loop
        public bool IsHappy2(int n)
        {
            int y = n;
            HashSet<int> set = new HashSet<int>();
            set.Add(y);
            while (y > 0)
            {
                y = SumSquare(y);
                if (y == 1) return true;
                if (set.Contains(y)) return false;
                set.Add(y);
            }
            if (y == 1 || y == 7 || y == 10) return true;
            return false;
        }
    }
}
